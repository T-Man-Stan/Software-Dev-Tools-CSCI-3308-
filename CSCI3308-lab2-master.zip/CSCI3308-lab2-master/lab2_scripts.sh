#!/bin/bash
# Authors : Trevor Stanley (TManStan)
# Date: 2/1/2019

#Problem 1 Code:
#Make sure to document how you are solving each problem!


#2.1 & 2.2:
echo "Enter a File Name:"
read filename
echo "Enter a regex command:"
read regexp

grep $regexp $filename

#2.3
#grep -E "^[0-9]{3}-[0-9]{3}-[0-9]{4}$" regex_practice.txt | wc -l
grep -E "^((\([0-9]{3}\) )|([0-9]{3}\-))[0-9]{3}\-[0-9]{4}$" regex_practice.txt | wc -l 
grep -E "^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[a-z]{2,}" regex_practice.txt | wc -l
grep -E "^((\([0-9]{3}\))|([0-9]{3}\-))[0-9]{3}\-[0-9]{4}$" regex_practice.txt | grep ^303 >>phone_results.txt
grep -E "^[a-zA-Z0-9][-\._a-zA-Z0-9]+@geocities.com" regex_practice.txt >> email_results.txt
#grep "^[a-zA-Z0-9][-\._a-zA-Z0-9]*@[a-zA-Z0-9][-\.a-zA-Z0-9]+@geocities.com" regex_practice.txt | grep -v "geociities.com" >>email_results.txt
#grep "^[a-zA-Z0-9][-\._a-zA-Z0-9]*@[a-zA-Z0-9][-\.a-zA-Z0-9]*\.(com|edu|info|gov|int|mil|net|org|biz|name|museum|coop|aero|pro|tv|[a-zA-Z]{2})$" regex_practice.txt | grep -v "geociities.com" >>email_results.txt
grep  -E "$regexp" regex_practice.txt >> command_results.txt